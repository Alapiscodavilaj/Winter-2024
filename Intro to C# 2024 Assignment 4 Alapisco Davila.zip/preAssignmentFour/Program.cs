﻿namespace AssingmenFour3154062
{
    public enum seatValue
    {
        A ,
        B ,
        C ,
        D 
    }
    public class Row
    {
        public List<Seat> Seats { get; set; }

        public Row()
        { 
            Seats = new List<Seat>
            {

            };
  
            for (int i = 0; i <4; i++)
            {
                if (i == 0)
                {
                    Seats.Add(new Seat(seatValue.A, this) { });
                }

                if (i == 1)
                {
                    Seats.Add(new Seat(seatValue.B, this) { });
                }

                if (i == 2)
                {
                    Seats.Add(new Seat(seatValue.C, this) { });
                }

                if (i == 3)
                {
                    Seats.Add(new Seat(seatValue.D, this) { });
                }

            }
        }
    }
    public class Passenger
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public bool WindowPreference { get; set; }

        public Seat Seat { get; set; }

        public Passenger(string firstName, string lastName, Seat seat)
        {
            FirstName = firstName;
            LastName = lastName;
            WindowPreference = false;
            Seat = seat;
        }
    }
    public class Seat
    {   
        public seatValue SeatValue { get; set; }
        public bool Occupied { get; set; }

        public Passenger Passenger { get; set; }
        public Row Row { get; set; }

        public Seat(seatValue letter, Row row)
        {
            SeatValue = letter;
            Row = row;
            Occupied = false;
        }
    }
    public class Airplane
    {
        public List<Row> Rows { get; set; }

        public Airplane()
        {
            Rows = new List<Row> 
            { 

            };

            for (int i = 0; i < 12; i++)
            {
                Rows.Add(new Row { });
            }
        }
    }

    public class Program
    {
        public static void Main(String[] args)
        {

            void showCurrentSeats(Airplane newAirplane)
            {
                foreach (var row in newAirplane.Rows)
                {

                    if (row == null)
                    {
                        continue;
                    }

                    foreach (var seat in row.Seats)
                    {
                        if (seat.Occupied == false)
                        { Console.Write(" " + seat.SeatValue + " "); }
                        else
                        {
                            // https://www.aspsnippets.com/questions/158554/Display-initials-two-characters-from-name-using-C-and-VBNet-in-ASPNet/ 
                            string passengerName = (seat.Passenger.FirstName.Substring(0,1) + seat.Passenger.LastName.Substring(0,1));
                            

                            Console.Write(passengerName);
                        }

                    }
                    Console.WriteLine("");
                }
            }
            Airplane newAirplane = new Airplane();

            void printOptions()
            {
                Console.WriteLine("Please choose from one of the following options:");
                Console.WriteLine("1. Select a New Seat");
                Console.WriteLine("2. Show Current Seats");
                Console.WriteLine("3. Exit the Ticket Booking App");
            }


            void printWindowPreference()
            {
                Console.WriteLine("Please choose from one of the following options:");
                Console.WriteLine("1. Window");
                Console.WriteLine("2. Aisle");
                Console.WriteLine("3. Do not Care");
            }

            void preferenceWindow(string firstName, string lastName) 
            {
                
                bool checkOut = true;

                foreach (var row in newAirplane.Rows)
                {
                    if (checkOut == false) { break; }

                    if (row == null)
                    {
                        continue;
                    }

                    foreach (var seat in row.Seats)
                    {
                        if (seat.SeatValue == seatValue.A || seat.SeatValue == seatValue.D) {
                        
                            if (seat.Occupied == true) { continue; }
                        
                            else
                        {
                            seat.Passenger = new Passenger(firstName, lastName, seat);


                            seat.Occupied = true;
                            checkOut = false;
                            break;
                        
                            }
                        }
                    }
                }
            }

            void preferenceAisle(string firstName, string lastName)
            {

                bool checkOut = true;

                foreach (var row in newAirplane.Rows)
                {
                    if (checkOut == false) { break; }

                    if (row == null)
                    {
                        continue;
                    }

                    foreach (var seat in row.Seats)
                    {
                        if (seat.SeatValue == seatValue.C || seat.SeatValue == seatValue.B)
                        {

                            if (seat.Occupied == true) { continue; }

                            else
                            {
                                seat.Passenger = new Passenger(firstName, lastName, seat);


                                seat.Occupied = true;
                                checkOut = false;
                                break;

                            }
                        }
                    }
                }
            }

            void assingFirstAvailable(string firstName, string lastName)
            {
                bool checkOut = true;

                foreach (var row in newAirplane.Rows)
                {
                    if (checkOut == false) { break; }

                    if (row == null)
                    {
                        continue;
                    }

                    foreach (var seat in row.Seats)
                    {
                        if (seat.Occupied == true) { continue; }
                        else
                        {
                            seat.Passenger = new Passenger(firstName, lastName, seat);


                            seat.Occupied = true;
                            checkOut = false;
                            break;
                        }
                    }

                }

            }

            bool checkAvailability()
            {

                foreach (var row in newAirplane.Rows)
                {

                    if (row == null)
                    {
                        continue;
                    }

                    foreach (var seat in row.Seats)
                    {
                        if (seat.Occupied == false)
                        { return true; }

                    }
                }
                return false;
            }

            void newSeat()
            {
                if (!checkAvailability()) {

                    Console.WriteLine("There are no more seats :(");
                    return;
                }

                string firstName = null;
                string lastName = null;
                bool windowPreference = false;

                Console.WriteLine("Please enter your Firstname");
                firstName = Console.ReadLine();
                Console.WriteLine("Please enter your Lastname");
                lastName = Console.ReadLine();
                

                int option = 0;
               
                    printWindowPreference();
                    try
                    {
                        option = int.Parse(Console.ReadLine());
                    }
                    catch { }
                    if (option == 1) { preferenceWindow(firstName, lastName); }
                    else if (option == 2) { preferenceAisle(firstName, lastName);}
                    else { assingFirstAvailable(firstName, lastName); }
                  
            }
            // https://www.youtube.com/watch?v=qBI7Qnz9Zho used the video to know how to make the option menu

            int option = 0;
            do
            {
                printOptions();
                try
                {
                    option = int.Parse(Console.ReadLine());
                }
                catch { }
                if (option == 1) { checkAvailability(); newSeat(); }
                else if (option == 2) { showCurrentSeats(newAirplane); }
                else if (option == 3) { break; }
                else { option = 0; }
            }

            while (option != 3);
            Console.WriteLine("Thank you and have a nice day :)");
        }
    }
}